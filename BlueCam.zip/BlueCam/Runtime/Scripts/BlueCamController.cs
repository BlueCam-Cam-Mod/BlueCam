using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class BlueCamController : MonoBehaviour
{
    public Camera[] cameras;
    public RawImage cameraDisplay;
    public Button recordButton, captureButton, micButton, switchCamButton;
    public Text feedbackText;

    private AudioSource micAudioSource;
    private string questMicDevice;
    private bool isRecording = false;
    private bool isMicOn = false;
    private int currentCameraIndex = 0;

    private string videoSavePath;
    private MemoryStream audioDataStream;
    private Texture2D videoFrameBuffer;

    void Start()
    {
        if (cameras.Length > 0)
        {
            SetActiveCamera(0);
        }

        recordButton.onClick.AddListener(ToggleRecording);
        captureButton.onClick.AddListener(CaptureImage);
        micButton.onClick.AddListener(ToggleMicrophone);
        switchCamButton.onClick.AddListener(SwitchCamera);

        micAudioSource = gameObject.AddComponent<AudioSource>();
        micAudioSource.loop = true;

        string[] micDevices = Microphone.devices;
        if (micDevices.Length > 0)
        {
            questMicDevice = micDevices[0];
            ShowFeedback($"Microphone detected: {questMicDevice}");
        }
        else
        {
            ShowFeedback("No microphone detected. Check permissions.");
        }
    }

    void ToggleRecording()
    {
        isRecording = !isRecording;
        if (isRecording)
        {
            StartRecording();
        }
        else
        {
            StopRecording();
        }
    }

    void StartRecording()
    {
        videoSavePath = Path.Combine(Application.persistentDataPath, "BlueCam_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(videoSavePath);

        videoFrameBuffer = new Texture2D(cameras[currentCameraIndex].targetTexture.width, cameras[currentCameraIndex].targetTexture.height, TextureFormat.RGB24, false);
        audioDataStream = new MemoryStream();

        if (questMicDevice != null)
        {
            micAudioSource.clip = Microphone.Start(questMicDevice, true, 10, 44100);
            while (!(Microphone.GetPosition(questMicDevice) > 0)) { }
            micAudioSource.Play();
        }

        ShowFeedback("Recording started.");
    }

    void StopRecording()
    {
        micAudioSource.Stop();
        if (questMicDevice != null)
        {
            Microphone.End(questMicDevice);
        }

        ProcessVideo();
        audioDataStream.Dispose();
        ShowFeedback("Recording stopped.");
    }

    void ProcessVideo()
    {
        string videoOutputPath = Path.Combine(videoSavePath, "video.mp4");
        ShowFeedback($"Video saved to: {videoOutputPath}");
    }

    void CaptureImage()
    {
        string imagePath = Path.Combine(Application.persistentDataPath, "BlueCam_Image_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png");

        RenderTexture.active = cameras[currentCameraIndex].targetTexture;
        Texture2D capturedImage = new Texture2D(cameras[currentCameraIndex].targetTexture.width, cameras[currentCameraIndex].targetTexture.height, TextureFormat.RGB24, false);
        capturedImage.ReadPixels(new Rect(0, 0, cameras[currentCameraIndex].targetTexture.width, cameras[currentCameraIndex].targetTexture.height), 0, 0);
        capturedImage.Apply();
        RenderTexture.active = null;

        File.WriteAllBytes(imagePath, capturedImage.EncodeToPNG());
        ShowFeedback($"Image saved to: {imagePath}");
    }

    void ToggleMicrophone()
    {
        isMicOn = !isMicOn;

        if (isMicOn)
        {
            if (questMicDevice != null)
            {
                micAudioSource.clip = Microphone.Start(questMicDevice, true, 10, 44100);
                while (!(Microphone.GetPosition(questMicDevice) > 0)) { }
                micAudioSource.Play();
                ShowFeedback("Microphone enabled.");
            }
        }
        else
        {
            micAudioSource.Stop();
            if (questMicDevice != null)
            {
                Microphone.End(questMicDevice);
            }
            ShowFeedback("Microphone disabled.");
        }
    }

    void SwitchCamera()
    {
        currentCameraIndex = (currentCameraIndex + 1) % cameras.Length;
        SetActiveCamera(currentCameraIndex);
        ShowFeedback($"Switched to Camera {currentCameraIndex + 1}");
    }

    void SetActiveCamera(int index)
    {
        for (int i = 0; i < cameras.Length; i++)
        {
            cameras[i].gameObject.SetActive(i == index);
        }

        cameraDisplay.texture = cameras[index].targetTexture;
    }

    void ShowFeedback(string message)
    {
        if (feedbackText != null)
        {
            feedbackText.text = message;
        }
        Debug.Log(message);
    }
}
