using UnityEngine;
using UnityEngine.UI;

public class BlueCamController : MonoBehaviour
{
    public Camera[] cameras;
    public float fovStep = 5f;
    public float minFov = 15f;
    public float maxFov = 90f;
    private int currentCameraIndex = 0;

    private AudioSource audioSource;
    private bool isRecording = false;
    private bool isMuted = false;

    public string screenshotFileName = "Screenshot";

    public Button increaseFovButton;
    public Button decreaseFovButton;
    public Button switchCameraButton;
    public Button toggleRecordingButton;
    public Button captureScreenshotButton;
    public Button muteButton;
    public Button unmuteButton;

    void Start()
    {
        if (cameras.Length > 0) EnableCamera(0);

        audioSource = GetComponent<AudioSource>();
        if (audioSource == null) audioSource = gameObject.AddComponent<AudioSource>();

        if (increaseFovButton != null) increaseFovButton.onClick.AddListener(IncreaseFov);
        if (decreaseFovButton != null) decreaseFovButton.onClick.AddListener(DecreaseFov);
        if (switchCameraButton != null) switchCameraButton.onClick.AddListener(SwitchCamera);
        if (toggleRecordingButton != null) toggleRecordingButton.onClick.AddListener(ToggleRecording);
        if (captureScreenshotButton != null) captureScreenshotButton.onClick.AddListener(CaptureScreenshot);
        if (muteButton != null) muteButton.onClick.AddListener(ToggleMute);
        if (unmuteButton != null) unmuteButton.onClick.AddListener(ToggleMute);
    }

    public void IncreaseFov()
    {
        if (cameras[currentCameraIndex] != null)
            cameras[currentCameraIndex].fieldOfView = Mathf.Clamp(cameras[currentCameraIndex].fieldOfView + fovStep, minFov, maxFov);
    }

    public void DecreaseFov()
    {
        if (cameras[currentCameraIndex] != null)
            cameras[currentCameraIndex].fieldOfView = Mathf.Clamp(cameras[currentCameraIndex].fieldOfView - fovStep, minFov, maxFov);
    }

    public void SwitchCamera()
    {
        if (cameras.Length > 0)
        {
            cameras[currentCameraIndex].enabled = false;
            currentCameraIndex = (currentCameraIndex + 1) % cameras.Length;
            EnableCamera(currentCameraIndex);
        }
    }

    private void EnableCamera(int index)
    {
        if (cameras[index] != null) cameras[index].enabled = true;
    }

    public void ToggleRecording()
    {
        if (isRecording) StopRecording();
        else StartRecording();
    }

    private void StartRecording()
    {
        audioSource.clip = Microphone.Start(null, true, 10, 44100);
        isRecording = true;
    }

    private void StopRecording()
    {
        if (isRecording)
        {
            Microphone.End(null);
            isRecording = false;
        }
    }

    public void ToggleMute()
    {
        if (audioSource != null)
        {
            isMuted = !isMuted;
            audioSource.mute = isMuted;
        }
    }

    public void CaptureScreenshot()
    {
        string path = $"{screenshotFileName}_{System.DateTime.Now:yyyy-MM-dd_HH-mm-ss}.png";
        ScreenCapture.CaptureScreenshot(path);
    }
}
