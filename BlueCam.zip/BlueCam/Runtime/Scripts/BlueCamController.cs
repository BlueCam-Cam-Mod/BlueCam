using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class BlueCamController : MonoBehaviour
{

    public Camera virtualCamera;
    public RawImage cameraDisplay;
    public Button recordButton, captureButton, micButton;
    public Text feedbackText;


    private AudioSource micAudioSource;
    private string questMicDevice;
    private bool isMicOn = false;

    private bool isRecording = false;
    private string videoSavePath;
    private int frameCount = 0;
    private Texture2D videoFrameBuffer;

    void Start()
    {

        if (virtualCamera.targetTexture == null)
        {
            RenderTexture renderTexture = new RenderTexture(1920, 1080, 24);
            virtualCamera.targetTexture = renderTexture;
        }
        cameraDisplay.texture = virtualCamera.targetTexture;

        recordButton.onClick.AddListener(ToggleRecording);
        captureButton.onClick.AddListener(CaptureImage);
        micButton.onClick.AddListener(ToggleMicrophone);

        micAudioSource = gameObject.AddComponent<AudioSource>();
        micAudioSource.loop = true;

        string[] micDevices = Microphone.devices;
        if (micDevices.Length > 0)
        {
            questMicDevice = micDevices[0];
            ShowFeedback($"Microphone detected: {questMicDevice}");
        }
        else
        {
            ShowFeedback("No microphone found. Please check permissions!");
        }
    }

    void ToggleRecording()
    {
        isRecording = !isRecording;
        if (isRecording)
        {
            StartRecording();
        }
        else
        {
            StopRecording();
        }
    }

    void StartRecording()
    {
        ShowFeedback("Recording started...");
        videoSavePath = Path.Combine(Application.persistentDataPath, "BlueCam_Video_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(videoSavePath);
        frameCount = 0;
        videoFrameBuffer = new Texture2D(virtualCamera.targetTexture.width, virtualCamera.targetTexture.height, TextureFormat.RGB24, false);
    }

    void StopRecording()
    {
        ShowFeedback($"Recording stopped. Frames saved at: {videoSavePath}");
        videoFrameBuffer = null;
    }

    void CaptureImage()
    {
        ShowFeedback("Capturing image...");
        string imagePath = Path.Combine(Application.persistentDataPath, "BlueCam_Image_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png");

        RenderTexture.active = virtualCamera.targetTexture;
        Texture2D capturedImage = new Texture2D(virtualCamera.targetTexture.width, virtualCamera.targetTexture.height, TextureFormat.RGB24, false);
        capturedImage.ReadPixels(new Rect(0, 0, virtualCamera.targetTexture.width, virtualCamera.targetTexture.height), 0, 0);
        capturedImage.Apply();
        RenderTexture.active = null;

        File.WriteAllBytes(imagePath, capturedImage.EncodeToPNG());
        ShowFeedback($"Image saved at: {imagePath}");
    }

    void ToggleMicrophone()
    {
        if (questMicDevice == null)
        {
            ShowFeedback("No microphone detected. Cannot toggle microphone.");
            return;
        }

        isMicOn = !isMicOn;
        if (isMicOn)
        {
            ShowFeedback("Microphone enabled.");
            micAudioSource.clip = Microphone.Start(questMicDevice, true, 10, 44100);
            while (!(Microphone.GetPosition(questMicDevice) > 0)) { }
            micAudioSource.Play();
        }
        else
        {
            ShowFeedback("Microphone disabled.");
            micAudioSource.Stop();
            Microphone.End(questMicDevice);
        }
    }

    void ShowFeedback(string message)
    {
        if (feedbackText != null)
        {
            feedbackText.text = message;
        }
        Debug.Log(message);
    }
}
